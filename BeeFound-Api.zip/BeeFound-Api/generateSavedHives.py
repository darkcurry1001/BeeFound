import requests
import json
import random
import os
from tqdm import tqdm

# List of example tokens
tokens = [
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDYyNzIxMDksInJvbGUiOiJiZWVrZWVwZXIiLCJ0eXBlIjoic2Vzc2lvbiIsInVzZXJfaWQiOjF9.5aH-ZN5mEQBjIh1UxCAIcSUIstik1ZcMsVKnQmox25Y',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDYyNzIxMjEsInJvbGUiOiJiZWVrZWVwZXIiLCJ0eXBlIjoic2Vzc2lvbiIsInVzZXJfaWQiOjJ9.cCnzsvEV73qaIkIokUVZIJ9nOKc0oJTVBxfpdk7YRD0',
    # Add more tokens as needed
]

# Function to generate random coordinates near Austria
def generate_random_coordinates():
    latitude = round(random.uniform(46.5, 49.5), 6)
    longitude = round(random.uniform(9, 17), 6)
    return latitude, longitude

# Function to make the API request
def make_api_request(token, latitude, longitude, id=0):
    url = 'http://localhost:3000/api/hive/save'
    headers = {'Token': token,
        'Content-Type': 'application/json'}
    response = requests.post(url, headers=headers, data=json.dumps({
                                                                    'Latitude': str(latitude),
                                                                    'Longitude': str(longitude),
                                                                    'Type': 'saved',
                                                                    "Name": f'Test Hive {id}',
                                                                }))

    # Print the response for debugging (you can remove this in production)
    print(response)

# Generate 50 random hive locations
offset = 11
for i in tqdm(range(2), desc="Sending requests"):
    # Select a random token from the list
    selected_token = random.choice(tokens)

    # Generate random coordinates
    latitude, longitude = generate_random_coordinates()

    # Make the API request
    make_api_request(selected_token, latitude, longitude, i+offset)