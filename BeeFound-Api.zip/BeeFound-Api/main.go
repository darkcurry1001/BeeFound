package main

import (
	"BeeFound-Api/auth"
	_ "BeeFound-Api/docs"
	"BeeFound-Api/initializers"
	"BeeFound-Api/models"
	"BeeFound-Api/routes"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/gofiber/swagger"
	"log"
	"os"
)

func setupRoutes(app *fiber.App) {
	app.Get("/api/", routes.HealthCheck)
	app.Get("/swagger/*", swagger.HandlerDefault) // default

	// Auth
	app.Post("/api/auth/login", routes.Login)
	app.Post("/api/auth/signup", routes.CheckUserBody, routes.Signup)
	app.Get("/api/auth/refresh", auth.Refresh, routes.Refresh)

	// Test api for auth check
	app.Get("/api/auth/test", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.TestRouteLogin)

	// User
	app.Get("/api/user", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.GetUser)
	app.Put("/api/user", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}),
		routes.CheckUserBody, routes.UpdateUser)
	app.Delete("/api/user", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.DeleteUser)

	// Hive
	app.Get("/api/hive", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.GetHives)
	app.Get("/api/hive/img", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.GetHiveImg)
	app.Delete("/api/hive", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.RemoveHive)

	// found hives
	app.Post("/api/hive/found", auth.Authorize([]models.UserRole{models.StandardRole, models.BeeKeeperRole}), routes.CheckImageFile, routes.CheckHiveBody, routes.FoundHive)
	app.Put("/api/hive/navigate", auth.Authorize([]models.UserRole{models.BeeKeeperRole}), routes.NavigateHive)

	// saved hives
	app.Post("/api/hive/save", auth.Authorize([]models.UserRole{models.BeeKeeperRole}), routes.CheckHiveBody, routes.SaveHive)
	app.Put("/api/hive/save", auth.Authorize([]models.UserRole{models.BeeKeeperRole}), routes.CheckHiveBody, routes.EditHive)
	app.Put("/api/hive/save/search", auth.Authorize([]models.UserRole{models.BeeKeeperRole}), routes.SearchHive)
	app.Put("/api/hive/save/found", auth.Authorize([]models.UserRole{models.BeeKeeperRole}), routes.FoundOwnHive)
}

func init() {
	initializers.LoadEnvVariables()

	// Database
	initializers.InitDatabase()
}

// @securitydefinitions.apikey Token
// @in header
// @name Token
// @description JWT Session Token

// @securitydefinitions.apikey Refresh
// @in header
// @name Token
// @description JWT Refresh Token

// @title BeeFound - Rest API
// @version 1.0
// @description This is the Rest API for the Mobile Computing project.
// @description The API is used for login, handling hives and more.<br />
// @description The API is secured with JWT.
// @description To decode Tokens (without the secret) use the following link: <a href="https://jwt.io/">JWT</a>
// @host skeller.at:3000
// @BasePath /api/
// @schemes http
func main() {
	// Fiber instance
	app := fiber.New(fiber.Config{
		BodyLimit: 1024 * 1024 * 50, // 50mb
	})

	// Middleware
	app.Use(recover.New())
	app.Use(cors.New())

	// routes
	setupRoutes(app)

	// Start Server
	if err := app.Listen(":" + os.Getenv("PORT")); err != nil {
		log.Fatal(err)
	}

	// Close Database connection when server is closed
	//defer database.DBConn.Close()
}
