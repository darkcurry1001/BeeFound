package routes

import "github.com/gofiber/fiber/v2"

// TestRouteLogin godoc
// @Summary Test route for session token check
// @Description Get a message if the server is up and running and session token is valid
// @Tags login/signup
// @Accept */*
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Router /auth/test/ [get]
func TestRouteLogin(c *fiber.Ctx) error {

	res := map[string]interface{}{
		"data": "Server is up and running",
	}

	if err := c.JSON(res); err != nil {
		return err
	}

	return nil
}
