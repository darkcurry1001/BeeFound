package routes

import (
	"BeeFound-Api/auth"
	"BeeFound-Api/database"
	"BeeFound-Api/models"
	"github.com/gofiber/fiber/v2"
	"golang.org/x/crypto/bcrypt"
	"log"
)

// Login godoc
// @Summary Login to existing account.
// @Description Login with username and password to get access to existing user account.
// @Description if Login is successful, a JWT Session and Refresh token will be returned.
// @Tags login/signup
// @Accept json
// @Produce json
// @Param login body models.Login true "User"
// @Success 200 {object} map[string]interface{}
// @Router /auth/login/ [post]
func Login(c *fiber.Ctx) error {
	var body models.User
	log.Default().Println(c.Body())
	if err := c.BodyParser(&body); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to parse body, please check your request body",
			"description": err,
		})
	}

	if err := body.ValidateLogin(); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Validation of body failed, please check your request body",
			"description": err,
		})
	}

	var user models.User
	if body.Username != "" {
		database.DBConn.First(&user, "username = ? or email = ?", body.Username, body.Username)
	}

	if user.ID == 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid username/email or password",
		})
	}

	err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(body.Password))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid username/email or password",
		})
	}

	session, refresh, err := auth.CreateTokenPair(user)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Error logging in",
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":           "Login successful",
		"session_token": session,
		"refresh_token": refresh,
	})
}

// Signup godoc
// @Summary Signup a new account.
// @Description Signup with username and password and additional data.
// @Description if Signup is successful, a JWT Session and Refresh token will be returned.
// @Tags login/signup
// @Accept json
// @Produce json
// @Param user body models.User true "User"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /auth/signup/ [post]
func Signup(c *fiber.Ctx) error {
	var body = c.Locals("body").(models.User)

	_, err := models.CheckDuplicateUsers(body.Username, body.Email)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to create user",
			"description": err.Error(),
		})
	}

	result := database.DBConn.Create(&body)
	if result.Error != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to create user",
			"description": err,
		})
	}

	session, refresh, err := auth.CreateTokenPair(body)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Error logging in",
			"description": err.Error(),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":           "Login successful",
		"session_token": session,
		"refresh_token": refresh,
	})
}

// Refresh godoc
// @Summary Refresh using the refresh token.
// @Description if Refresh is successful, a new JWT Session and Refresh token will be returned.
// @Tags login/signup
// @Accept json
// @Produce json
// @Security Refresh
// @Success 200 {object} map[string]interface{}
// @Router /auth/refresh/ [get]
// @securityDefinitions.basic BasicAuth
func Refresh(c *fiber.Ctx) error {
	session, refresh, err := auth.CreateTokenPair(c.Locals("user").(models.User))

	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Error refreshing",
			"description": err.Error(),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":           "Refresh successful",
		"session_token": session,
		"refresh_token": refresh,
	})
}
