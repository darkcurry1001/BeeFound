package routes

import (
	"BeeFound-Api/auth"
	"BeeFound-Api/database"
	"BeeFound-Api/models"
	"github.com/gofiber/fiber/v2"
	"github.com/jinzhu/gorm"
	"golang.org/x/crypto/bcrypt"
	"log"
	"strconv"
	"strings"
)

// GetUser godoc
// @Summary Get Users with the given user IDs.
// @Description
// @Tags User
// @Accept */*
// @param id query []int true "User ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /user [get]
func GetUser(c *fiber.Ctx) error {
	stringIds := strings.Split(c.Query("id"), ",")
	var ids []int
	if stringIds[0] == "" {
		ids = append(ids, int(c.Locals("user_id").(uint)))
		//return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
		//	"error":       "No ID given",
		//	"description": "Please provide at least one ID",
		//})
	} else {
		for _, i := range stringIds {
			j, err := strconv.Atoi(i)
			if err != nil {
				return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
					"error":       "Wrong ID format",
					"description": err,
				})
			}
			ids = append(ids, j)
		}
	}

	var users []models.User

	results := database.DBConn.Find(&users, ids)
	if results.Error != nil {
		if gorm.IsRecordNotFoundError(results.Error) {
			return c.Status(fiber.StatusOK).JSON(fiber.Map{
				"msg": "No user found",
			})
		}
	}

	if len(users) == 0 {
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"msg":   "Found users",
			"users": models.ParseUsers(users),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":  "Found user",
		"user": models.ParseUser(users[0]),
	})
}

// UpdateUser godoc
// @Summary Update an existing User.
// @Description Update with username and password and additional data.
// @Description if Signup is successful, a new JWT Session and Refresh token will be returned.
// @Tags User
// @Accept json
// @Produce json
// @Param user body models.User true "User"
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /user [put]
func UpdateUser(c *fiber.Ctx) error {
	var userId = c.Locals("user_id").(uint)
	var body = c.Locals("body").(models.User)

	var user models.User
	database.DBConn.First(&user, "ID == ?", userId)

	if user.ID == 0 {
		return c.Status(401).JSON(fiber.Map{
			"err":         "Unauthorized",
			"description": "User does not exist",
		})
	}

	// update user
	existingUser, err := models.CheckDuplicateUsers(body.Username, body.Email)
	if existingUser == nil && err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to change user",
			"description": err.Error(),
		})
	}

	if existingUser.ID != userId {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to change user",
			"description": "there is already another user with this username or email",
		})
	}

	log.Default().Println("test1")
	user.Username = body.Username
	user.Email = body.Email
	user.Role = body.Role
	user.Password = body.Password
	user.Phone = body.Phone

	log.Default().Println("test2")
	result := database.DBConn.Save(user)
	if result.Error != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to create user",
			"description": err,
		})
	}

	log.Default().Println("test3")
	// generate new token pair
	session, refresh, err := auth.CreateTokenPair(user)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Error logging in",
			"description": err.Error(),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":           "Login successful",
		"session_token": session,
		"refresh_token": refresh,
	})
}

// DeleteUser godoc
// @Summary Delete an existing User.
// @Description Delete with username and password and also the id inside the Token has to match.
// @Tags User
// @Accept json
// @Produce json
// @Param user body models.Login true "User login data"
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /user [delete]
func DeleteUser(c *fiber.Ctx) error {
	var userId = c.Locals("user_id").(uint)

	var body models.User
	log.Default().Println(c.Body())
	if err := c.BodyParser(&body); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to parse body, please check your request body",
			"description": err,
		})
	}

	if err := body.ValidateLogin(); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Validation of body failed, please check your request body",
			"description": err,
		})
	}

	var user models.User
	if body.Username != "" {
		database.DBConn.First(&user, "username = ? or email = ?", body.Username, body.Username)
	}

	if user.ID == 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid username/email or password",
		})
	}

	err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(body.Password))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid username/email or password",
		})
	}

	result := database.DBConn.Delete(&user, userId)
	if result.Error != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to delete user",
			"description": err,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":     "User was deleted",
		"user_id": userId,
	})
}
