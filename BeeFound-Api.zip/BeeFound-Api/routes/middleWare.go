package routes

import (
	"BeeFound-Api/auth"
	"BeeFound-Api/models"
	"encoding/json"
	"github.com/gofiber/fiber/v2"
	"io"
	"log"
	"math"
	"os"
	"regexp"
	"strconv"
	"strings"
)

func CheckUserBody(c *fiber.Ctx) error {
	var body models.User
	if err := c.BodyParser(&body); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to parse body, please check your request body",
			"description": err,
		})
	}

	if body.Role == models.AdminRole {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid role",
		})
	}
	if err := body.ValidateCreate(); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Validation of body failed, please check your request body",
			"description": err,
		})
	}

	hash, err := auth.HashPassword(body.Password)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to hash password",
			"description": err,
		})
	}
	body.Password = hash
	c.Locals("body", body)
	return c.Next()
}

func CheckHiveBody(c *fiber.Ctx) error {
	var role = c.Locals("role").(models.UserRole)
	var userId = c.Locals("user_id").(uint)
	var body models.Hive

	if strings.HasPrefix(c.GetReqHeaders()["Content-Type"][0], "multipart/form-data") {
		log.Default().Println(c.FormValue("json"))
		if err := json.Unmarshal([]byte(c.FormValue("json")), &body); err != nil {
			return c.Status(fiber.StatusBadRequest).SendString("Failed to parse JSON data")
		}

		body.Image = c.Locals("img").([]byte)
		body.UserID = userId

		if err := body.Validate(); err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Validation of body failed, please check your request body",
				"description": err,
			})
		}

		if role == models.StandardRole && body.Type == models.Saved {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Invalid type",
				"description": "Standard users can only search for hives",
			})
		}
		c.Locals("body", body)
		return c.Next()
	} else if c.Is("json") {
		if err := c.BodyParser(&body); err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Failed to parse body, please check your request body",
				"description": err,
			})
		}
		body.UserID = userId
		c.Locals("body", body)
		return c.Next()
	}
	return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
		"error": "Invalid body type",
	})
}

func CheckImageFile(c *fiber.Ctx) error {
	fileHeader, err := c.FormFile("img")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
			"msg":   "img key not found in form data",
		})
	}

	// Check if file is of type image or not
	fileExtension := regexp.MustCompile(`\.[a-zA-Z0-9]+$`).FindString(fileHeader.Filename)
	if fileExtension != ".jpg" && fileExtension != ".jpeg" && fileExtension != ".png" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": true,
			"msg":   "Invalid file type",
		})
	}

	// Read file content
	file, err := fileHeader.Open()
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": true,
			"msg":   err.Error(),
		})
	}

	img, err := io.ReadAll(file)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": true,
			"msg":   err.Error(),
		})
	}

	c.Locals("img", img)
	return c.Next()
}

const earthRadius = 6371 // Earth radius in kilometers
// CheckRadius godoc
// latL, lonL: latitude and longitude of the current location
// latH, lonH: latitude and longitude of the hive
func CheckRadius(latL float64, lonL float64, latH float64, lonH float64) bool {
	// Convert latitude and longitude from degrees to radians
	lat1Rad := degToRad(latL)
	lon1Rad := degToRad(lonL)
	lat2Rad := degToRad(latH)
	lon2Rad := degToRad(lonH)

	// Calculate differences
	dlat := lat2Rad - lat1Rad
	dlon := lon2Rad - lon1Rad

	// Haversine formula
	a := math.Sin(dlat/2)*math.Sin(dlat/2) +
		math.Cos(lat1Rad)*math.Cos(lat2Rad)*
			math.Sin(dlon/2)*math.Sin(dlon/2)
	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	// Distance in kilometers
	distance := earthRadius * c

	maxDist, err := strconv.ParseFloat(os.Getenv("USER_VIEW_RADIUS"), 64)
	if err != nil {
		return false
	}

	return distance <= maxDist
}

func degToRad(deg float64) float64 {
	return deg * (math.Pi / 180)
}
