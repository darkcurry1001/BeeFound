package routes

import (
	"BeeFound-Api/database"
	"BeeFound-Api/models"
	"bytes"
	"fmt"
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
)

//TODO: Think about performance:
// - endpoint for only locations?
// - lazy loading?
// - ...

//ToDO: separate array for navigated hives, or array with hive ids where navigated to

// GetHives godoc
// @Summary Get Hives
// @Description Get all Hives a user is allowed to see.
// @Description Normal users only can see searched and their found hives, beekeepers also their saved hives and all found hives.
// @Tags Hive
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive [get]
func GetHives(c *fiber.Ctx) error {
	var role models.UserRole = c.Locals("role").(models.UserRole)
	var userId uint = c.Locals("user_id").(uint)

	var searchedHives []models.Hive
	var foundHives []models.Hive
	var navigatedHives []models.Hive
	var savedHives []models.Hive

	if err := database.DBConn.Preload("User", func(db *gorm.DB) *gorm.DB {
		return database.DBConn.Select("id, email") // Select the fields you want from the User model
	}).Where("type = ? and searched = ?", models.Saved, true).Find(&searchedHives).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to get searched hives",
			"description": err,
		})
	}

	joinFound := database.DBConn.Preload("User", func(db *gorm.DB) *gorm.DB {
		return database.DBConn.Select("id, email") // Select the fields you want from the User model
	}).Table("hives").Joins("LEFT JOIN hive_navigations ON hive_navigations.hive_id = hives.id").
		Where("hive_navigations.hive_id IS NULL")
	joinNavigated := database.DBConn.Preload("User", func(db *gorm.DB) *gorm.DB {
		return database.DBConn.Select("id, email") // Select the fields you want from the User model
	}).Table("hives").InnerJoins("JOIN hive_navigations ON hive_navigations.hive_id = hives.id")

	if role == models.BeeKeeperRole {
		if err := joinFound.Where("type = ?", models.Found).Find(&foundHives).Error; err != nil {
			log.Default().Println("error1: ", err)
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error": "Failed to get searched hives",
			})
		}
		if err := joinNavigated.Where("type = ?", models.Found).Find(&navigatedHives).Error; err != nil {
			log.Default().Println("error2: ", err)
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error": "Failed to get searched hives",
			})
		}
		if err := database.DBConn.Preload("User", func(db *gorm.DB) *gorm.DB {
			return database.DBConn.Select("id, email") // Select the fields you want from the User model
		}).Where("user_id = ? AND type = ? AND searched = ?", userId, models.Saved, false).Find(&savedHives).Error; err != nil {
			log.Default().Println("error3: ", err)
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error": "Failed to get saved hives",
			})
		}

		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"msg":       "Found hives",
			"found":     foundHives,
			"navigated": navigatedHives,
			"searched":  searchedHives,
			"saved":     savedHives,
		})
	} else {
		if err := database.DBConn.Where("user_id = ? AND type = ?", userId, models.Found).Find(&foundHives).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Failed to get searched hives",
				"description": err,
			})
		}
		if err := joinNavigated.Where("hive_navigations.user_id = ? AND type = ?", userId, models.Found).Find(&navigatedHives).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Failed to get searched hives",
				"description": err,
			})
		}

		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"msg":       "Found hives",
			"found":     foundHives,
			"navigated": navigatedHives,
			"searched":  searchedHives,
			"saved":     savedHives,
		})
	}
}

// GetHiveImg godoc
// @Summary Get Hives Image
// @Description Get Hives Image for the given hive id.
// @Tags Hive
// @Param id query int true "Hive ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/img [get]
func GetHiveImg(c *fiber.Ctx) error {
	var role = c.Locals("role").(models.UserRole)
	var userId = c.Locals("user_id").(uint)
	hiveId, err := strconv.Atoi(c.Query("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Wrong ID format",
			"description": err,
		})
	}

	var hive models.Hive
	if role == models.BeeKeeperRole {
		if err := database.DBConn.Model(&models.Hive{}).Where("id = ?", hiveId).First(&hive).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Failed to get hive image",
				"description": err.Error(),
			})
		}
	} else {
		dist, err := strconv.ParseFloat(os.Getenv("USER_VIEW_RADIUS"), 64)
		if err != nil {
			dist = 0.1
		}
		var location models.Location
		err = c.BodyParser(&location)
		if err == nil {
			err := location.Validate()
			if err == nil {
				if err := database.DBConn.Model(&models.Hive{}).Where("id = ? AND"+
					"(user_id = ? OR distance(Latitude, Longitude, ?, ?) <= ?)",
					hiveId, userId, location.Latitude, location.Longitude, dist).First(&hive).Error; err != nil {
					return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
						"error":       "Failed to get hive image",
						"description": err.Error(),
					})
				}
			}
		}
		if err != nil {
			if err := database.DBConn.Model(&models.Hive{}).Where("id = ? AND user_id = ? ", hiveId, userId).First(&hive).Error; err != nil {
				return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
					"error":       "Failed to get hive image",
					"description": err.Error(),
				})
			}
		}
	}

	log.Default().Println("found hive: ", hive.ID)
	fileType := http.DetectContentType(hive.Image)
	if fileType == "text/plain; charset=utf-8" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Failed to get hive image",
			"description": "no image of hive found",
		})
	}
	log.Default().Println("type: ", fileType)
	c.Set("Content-Disposition",
		fmt.Sprintf("attachment; filename=hive-%d.", hiveId)+strings.Split(fileType, "/")[1])
	c.Set("Content-Type", fileType)
	return c.SendStream(bytes.NewReader(hive.Image))
}

// TODO: param json for Hive body for swagger

// FoundHive godoc
// @Summary Upload Found Hive
// @Tags Hive
// @Accept json
// @param json body models.Hive true "Hive"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/found [post]
func FoundHive(c *fiber.Ctx) error {
	var body = c.Locals("body").(models.Hive)
	warning := ""
	if body.Type == models.Saved {
		warning = " (Warning: Hive type was changed to found)"
	}
	body.Type = models.Found

	var nearbyHives []models.Hive
	dist, err := strconv.ParseFloat(os.Getenv("ADD_RADIUS"), 64)
	if err != nil {
		dist = 0.03
	}
	if err := database.DBConn.Model(&models.Hive{}).Where("distance(Latitude, Longitude, ?, ?) <= ? and type = ?",
		body.Latitude, body.Longitude, dist/1000, models.Found).Find(&nearbyHives).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "create hive not working",
			"description": err,
		})
	}
	if len(nearbyHives) > 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "create hive not working",
			"description": "Hive is too close to another one",
		})
	}
	if err := database.DBConn.Model(&models.Hive{}).Where("distance(Latitude, Longitude, ?, ?) <= ? and type = ?",
		body.Latitude, body.Longitude, dist/5000, models.Saved).Find(&nearbyHives).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "create hive not working",
			"description": err,
		})
	}
	if len(nearbyHives) > 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "create hive not working",
			"description": "Hive is too close to another one",
		})
	}

	// database new Hive with hive for c.Locals("body").(models.Hive)
	if err := database.DBConn.Create(&body).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "create hive not working",
			"description": err,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":  "Created hive successfully" + warning,
		"hive": body,
	})
}

// SaveHive godoc
// @Summary Upload new Hive to save as beekeeper.
// @Tags Hive
// @Accept json
// @param json body models.Hive true "Hive"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/save [post]
func SaveHive(c *fiber.Ctx) error {
	var body = c.Locals("body").(models.Hive)
	warning := ""
	if body.Type == models.Found {
		warning = " (Warning: Hive type was changed to saved)"
	}
	body.Type = models.Saved
	// database new Hive with hive for c.Locals("body").(models.Hive)
	if err := database.DBConn.Create(&body).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "create hive not working",
			"description": err,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg":  "Created hive successfully" + warning,
		"hive": body,
	})
}

// NavigateHive godoc
// @Summary Claim a Hive as beekeeper.
// @Description Beekeepers can claim a hive to navigate to it (if hiveID=0: removing navigation).
// @Tags Hive
// @Accept json
// @param id query int true "Hive ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/navigate [put]
func NavigateHive(c *fiber.Ctx) error {
	var userId uint = c.Locals("user_id").(uint)
	var hiveId, err = strconv.Atoi(c.Query("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Wrong ID format",
			"description": err,
		})
	}

	if hiveId == 0 {
		if err := database.DBConn.Where("user_id = ?", userId).Delete(&models.HiveNavigation{}).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Hive doesnt exist or no access",
				"description": err.Error(),
			})
		}
		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"msg": "Navigation successfully removed",
		})
	}

	var nav = models.HiveNavigation{
		UserID: userId,
		HiveID: uint(hiveId),
	}
	if err := database.DBConn.Table("hive_navigations").Where("user_id = ?", userId).Save(&nav).Error; err != nil {
		if err := database.DBConn.Table("hive_navigations").Create(&nav).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Err saving navigation in Database",
				"description": err,
			})
		}
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg": "Navigation successfully changed",
	})
}

// SearchHive godoc
// @Summary Beekeeper can set their hive as searched for.
// @Tags Hive
// @Accept json
// @param id query int true "Hive ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/save/search [put]
func SearchHive(c *fiber.Ctx) error {
	var userId uint = c.Locals("user_id").(uint)
	var hiveId, err = strconv.Atoi(c.Query("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Wrong ID format",
			"description": err,
		})
	}

	var hive models.Hive
	if err := database.DBConn.Model(&models.Hive{}).Where("id = ? and user_id = ?", hiveId, userId).First(&hive).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Hive doesnt exist or no access",
			"description": err.Error(),
		})
	}

	hive.Searched = true

	// Save the updated user record
	if err := database.DBConn.Save(&hive).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Error changing hive",
			"description": err.Error(),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg": "Hive set to searched",
	})
}

// FoundOwnHive godoc
// @Summary A beekeeper can set his lost hive as found.
// @Tags Hive
// @Accept json
// @param id query int true "Hive ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/save/found [put]
func FoundOwnHive(c *fiber.Ctx) error {
	var userId uint = c.Locals("user_id").(uint)
	var hiveId, err = strconv.Atoi(c.Query("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Wrong ID format",
			"description": err,
		})
	}

	var hive models.Hive
	if err := database.DBConn.Model(&models.Hive{}).Where("id = ? and user_id = ?", hiveId, userId).First(&hive).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Hive doesnt exist or no access",
			"description": err.Error(),
		})
	}

	hive.Searched = false

	// Save the updated user record
	if err := database.DBConn.Save(&hive).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Error changing hive",
			"description": err.Error(),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg": "removed search status of hive",
	})
}

// RemoveHive godoc
// @Summary Remove existing Hive.
// @Description Beekeepers can remove their saved hives and all found hives.
// @Description Normal users can only remove their found hives.
// @Tags Hive
// @Accept json
// @param id query int true "Hive ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive [delete]
func RemoveHive(c *fiber.Ctx) error {
	var userId uint = c.Locals("user_id").(uint)
	var role = c.Locals("role").(models.UserRole)
	var hiveId, err = strconv.Atoi(c.Query("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Wrong ID format",
			"description": err,
		})
	}

	if role == models.BeeKeeperRole {
		if err = database.DBConn.Where("id = ? and (user_id = ? or type = ?)", hiveId, userId, models.Found).Delete(&models.Hive{}).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Hive doesnt exist or no access",
				"description": err.Error(),
			})
		}
	} else {
		if err = database.DBConn.Where("id = ? and user_id = ?", hiveId, userId).Delete(&models.Hive{}).Error; err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"error":       "Hive doesnt exist or no access",
				"description": err.Error(),
			})
		}
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg": "hive removed successfully",
	})
}

// EditHive godoc
// @Summary Edit saved Hive.
// @Description Beekeepers can change their saved hives.
// @Tags Hive
// @Accept json
// @param id query int true "Hive ID"
// @Produce json
// @Security Token
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Router /hive/save [put]
func EditHive(c *fiber.Ctx) error {
	var userId uint = c.Locals("user_id").(uint)

	var hiveId, err = strconv.Atoi(c.Query("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Wrong ID format",
			"description": err,
		})
	}

	var hive models.Hive
	if err := database.DBConn.Model(&models.Hive{}).Where("id = ? and user_id = ?", hiveId, userId).First(&hive).Error; err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error":       "Hive doesnt exist or no access",
			"description": err.Error(),
		})
	}

	hive.Image = c.Locals("body").(models.Hive).Image
	hive.Info = c.Locals("body").(models.Hive).Info

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"msg": "changed hive successfully",
	})
}
