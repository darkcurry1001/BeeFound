package auth

import (
	"BeeFound-Api/models"
	"fmt"
	"github.com/dgrijalva/jwt-go"
	"golang.org/x/crypto/bcrypt"
	"os"
	"time"
)

func HashPassword(password string) (string, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hashedPassword), nil
}

var SessionTime = time.Duration(5)
var RefreshTokenTime = time.Duration(24 * 7)

func CreateSessionToken(user models.User) (string, error) {
	claims := jwt.MapClaims{}
	claims["user_id"] = user.ID
	claims["type"] = "session"
	claims["role"] = user.Role
	claims["exp"] = time.Now().Add(time.Hour * SessionTime).Unix() //Token expires after 5 hour
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(os.Getenv("JWT_SESSION_SECRET")))
	return tokenString, err
}

func CreateRefreshToken(user models.User) string {
	claims := jwt.MapClaims{}
	claims["user_id"] = user.ID
	claims["type"] = "refresh"
	claims["exp"] = time.Now().Add(time.Hour * RefreshTokenTime).Unix() //Token expires after 7 days
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, _ := token.SignedString([]byte(os.Getenv("JWT_REFRESH_SECRET")))
	return tokenString
}

func CreateTokenPair(user models.User) (string, string, error) {
	session, err := CreateSessionToken(user)
	if err != nil {
		return "", "", err
	}
	refresh := CreateRefreshToken(user)
	return session, refresh, nil
}

func VerifyToken(tokenString string, secret string) (jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok { // check if signing method is correct
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(secret), nil
	})
	if err != nil {
		return nil, err
	}
	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		if float64(time.Now().Unix()) > claims["exp"].(float64) {
			return nil, fmt.Errorf("token is expired")
		}
		return claims, nil
	} else {
		return nil, fmt.Errorf("token claim error")
	}
}
