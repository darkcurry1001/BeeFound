package auth

import (
	"BeeFound-Api/database"
	"BeeFound-Api/models"
	"fmt"
	"github.com/gofiber/fiber/v2"
	"log"
	"os"
	"slices"
)

func Authorize(roles []models.UserRole) fiber.Handler {
	return func(ctx *fiber.Ctx) error {
		tokenString := ctx.Get("Token")
		//log.Default().Println(tokenString)
		if tokenString == "" {
			return ctx.Status(401).JSON(fiber.Map{
				"err": "Unauthorized",
			})
		}
		claims, err := VerifyToken(tokenString, os.Getenv("JWT_SESSION_SECRET"))
		if err != nil {
			return ctx.Status(401).JSON(fiber.Map{
				"err":         "Unauthorized",
				"description": err,
			})
		}

		roleString, ok := claims["role"].(string)
		if !ok {
			return ctx.Status(401).JSON(fiber.Map{
				"err":         "Unauthorized",
				"description": "Role claim is missing " + roleString,
			})
		}

		role, err := models.ParseUserRole(roleString)
		if err != nil {
			fmt.Errorf("role does not exist")
		}

		if err != nil {
			return ctx.Status(401).JSON(fiber.Map{
				"err":         "Unauthorized",
				"description": err,
			})
		}
		if role != models.AdminRole && !slices.Contains(roles, role) {
			return ctx.Status(401).JSON(fiber.Map{
				"err": "Unauthorized (missing role)",
			})
		}

		id := uint(claims["user_id"].(float64))
		var user models.User
		database.DBConn.First(&user, id)

		if user.ID == 0 {
			return ctx.Status(401).JSON(fiber.Map{
				"err": "User does not exist",
			})
		}

		ctx.Locals("role", role)
		ctx.Locals("user_id", id)
		return ctx.Next()
	}
}

func Refresh(ctx *fiber.Ctx) error {
	tokenString := ctx.Get("Token")
	log.Default().Println(tokenString)
	if tokenString == "" {
		return ctx.Status(401).JSON(fiber.Map{
			"err": "Unauthorized",
		})
	}
	claims, err := VerifyToken(tokenString, os.Getenv("JWT_REFRESH_SECRET"))

	id := uint(claims["user_id"].(float64))

	if err != nil {
		return ctx.Status(401).JSON(fiber.Map{
			"err":         "Unauthorized",
			"description": err,
		})
	}

	var user models.User
	database.DBConn.First(&user, id)

	if user.ID == 0 {
		return ctx.Status(401).JSON(fiber.Map{
			"err": "Unauthorized",
		})
	}
	ctx.Locals("user", user)
	return ctx.Next()
}
