package models

import (
	"BeeFound-Api/database"
	"errors"
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
	//"github.com/jinzhu/gorm"
	//_ "github.com/jinzhu/gorm/dialects/sqlite"
	_ "gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type User struct {
	gorm.Model `swaggerignore:"true"`

	// has to be unique and between 4 and 50 characters
	Username string `gorm:"unique;not null" json:"username" example:"JohnDoe"`

	// has to be a valid email address
	Email string `gorm:"unique;not null" json:"email" example:"johnDoe@gmail.com"`

	// has to be between 6 and 50 characters
	Password string `gorm:"not null" json:"password" example:"testPSW123"`

	// has to be one of the following: admin, beekeeper, user
	Role UserRole `gorm:"default:'user'"  json:"role" example:"user"`

	// required false
	Phone string `grom:"default:null" json:"phone,omitempty" example:"+430123456789"`

	// required false
	ProfilePicture []byte `gorm:"type:bytea;default:null" json:"-" swaggerignore:"true"` // path to profile picture with default value

	Hives []Hive `json:"hives,omitempty" swaggerignore:"true"`
	// navigating to hive
	NavToHive uint `gorm:"default:null" json:"hives,omitempty" swaggerignore:"true"`
}

type PublicUser struct {
	Id       uint     `json:"id" example:"1"`
	Username string   `json:"username" example:"JohnDoe"`
	Email    string   `json:"email" example:"`
	Phone    string   `json:"phone,omitempty" example:"+430123456789"`
	Role     UserRole `json:"role" example:"user"`
}

// Login structure just for swagger documentation (example)
type Login struct {
	// has to be present in the database
	// alternative: email but in same field
	// example: JohnDoe
	Username string `json:"username" example:"JohnDoe"`
	// example: testPSW123
	Password string `json:"password" example:"testPSW123"`
}

func CheckDuplicateUsers(username, email string) (*User, error) {
	var user User
	result := database.DBConn.Where("username = ? OR email = ?", username, email).First(&user)
	if result.Error != nil {
		if errors.Is(result.Error, gorm.ErrRecordNotFound) {
			// Record not found, username and email are unique
			return nil, nil
		}
		// Some other error occurred
		return nil, result.Error
	}
	// Record found, username or email already exists
	err := errors.New("username or email already exists")
	return &user, err
}

func (u User) ValidateCreate() error {
	return validation.ValidateStruct(&u,
		validation.Field(&u.Username, validation.Required, validation.Length(4, 50)),
		validation.Field(&u.Email, validation.Required, is.Email),
		validation.Field(&u.Role, validation.Required, validation.In(BeeKeeperRole, StandardRole)),
		validation.Field(&u.Password, validation.Required, validation.Length(6, 50)),
	)
}

func (u User) ValidateLogin() error {
	return validation.ValidateStruct(&u,
		validation.Field(&u.Username, validation.Length(4, 320)),
		validation.Field(&u.Password, validation.Required, validation.Length(6, 50)),
	)
}

type UserRole string

const (
	AdminRole     UserRole = "admin"
	BeeKeeperRole UserRole = "beekeeper"
	StandardRole  UserRole = "user"
)

func ParseUserRole(role string) (UserRole, error) {
	switch UserRole(role) {
	case AdminRole, BeeKeeperRole, StandardRole:
		return UserRole(role), nil
	default:
		return "", errors.New("invalid role")
	}
}

func ParseUser(user User) PublicUser {
	return PublicUser{
		Id:       user.ID,
		Username: user.Username,
		Email:    user.Email,
		Phone:    user.Phone,
		Role:     user.Role,
	}
}
func ParseUsers(users []User) []PublicUser {
	var publicUsers []PublicUser
	for _, user := range users {
		publicUsers = append(publicUsers, ParseUser(user))
	}
	return publicUsers
}
