package models

import (
	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
	//"github.com/jinzhu/gorm"
	_ "gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type HiveType string

const (
	Found HiveType = "found"
	Saved HiveType = "saved"
)

type Hive struct {
	gorm.Model
	Longitude string   `gorm:"type:numeric;not null"`
	Latitude  string   `gorm:"type:numeric;not null"`
	UserID    uint     `gorm:"not null;foreignKey:UserID"` // user who found the hive
	User      User     `gorm:""`
	Type      HiveType `json:"type"`                                         // is the hive saved by a user
	Searched  bool     `json:"omitempty"`                                    // is the hive getting searched
	Navigated []User   `gorm:"many2many:hive_navigations;" json:"omitempty"` // is the hive claimed by a beekeeper
	Name      string   `json:"name,omitempty"`
	Info      string   `json:"info,omitempty"`      // additional info about the hive
	Image     []byte   `gorm:"type:bytea" json:"-"` // path to image of the hive
}

type HiveNavigation struct {
	UserID uint
	HiveID uint
}

type Location struct {
	Longitude string
	Latitude  string
}

// maybe separate validation for adding found hive or saving one
func (h Hive) Validate() interface{} {
	return validation.ValidateStruct(&h,
		validation.Field(&h.UserID, validation.Required),
		validation.Field(&h.Longitude, validation.Required, is.Longitude),
		validation.Field(&h.Latitude, validation.Required, is.Latitude),
		validation.Field(&h.Type, validation.Required, validation.In(Found, Saved)),
		validation.Field(&h.Image, validation.Required),
	)
}

func (l Location) Validate() interface{} {
	return validation.ValidateStruct(&l,
		validation.Field(&l.Longitude, validation.Required, is.Longitude),
		validation.Field(&l.Latitude, validation.Required, is.Latitude),
	)
}
