package initializers

import (
	"BeeFound-Api/database"
	"BeeFound-Api/models"
	"os"

	//"database/sql"
	"fmt"
	//"github.com/mattn/go-sqlite3"

	//"github.com/jinzhu/gorm"
	//_ "github.com/jinzhu/gorm/dialects/sqlite"
	//sqlite3 "github.com/mattn/go-sqlite3"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func InitDatabase() {
	var err error
	dsn := "user=" + os.Getenv("DB_USER") + " password=" + os.Getenv("DB_PASSWORD") +
		" dbname=" + os.Getenv("DB_NAME") + " host=" + os.Getenv("DB_HOST") + " port=" + os.Getenv("DB_PORT") +
		" sslmode=disable"
	database.DBConn, err = gorm.Open(postgres.Open(dsn), &gorm.Config{})

	if err != nil {
		panic("failed to connect to db:\n" + err.Error())
	}
	fmt.Println("DB connected")

	err = database.DBConn.AutoMigrate(&models.User{}, &models.Hive{})
	if err != nil {
		panic("failed to migrate db:\n" + err.Error())
	}
	fmt.Println("DB migrated")

	// define sql function to calculate distance between two points (harvesine formula)
	result := database.DBConn.Exec(
		"CREATE OR REPLACE FUNCTION distance(lat1 FLOAT, lon1 FLOAT, lat2 FLOAT, lon2 FLOAT) RETURNS numeric " +
			"LANGUAGE SQL\n    IMMUTABLE\n    RETURNS NULL ON NULL INPUT\n" +
			"RETURN 6371 * 2 * ASIN(SQRT(POWER(SIN((lat1 - abs(lat2)) * pi()/180 / 2), 2)" +
			"+ COS(lat1 * pi()/180 ) * COS(abs(lat2) * pi()/180) * POWER(SIN((lon1 - lon2) * pi()/180 / 2), 2)));")
	if result.Error != nil {
		panic("failed to create sql function")
	}
}
