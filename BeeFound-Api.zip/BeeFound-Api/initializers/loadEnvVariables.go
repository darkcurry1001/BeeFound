package initializers

import (
	"BeeFound-Api/auth"
	"github.com/joho/godotenv"
	"log"
	"os"
	"strconv"
	"time"
)

func getenv(key, fallback string) string {
	value := os.Getenv(key)
	if len(value) == 0 {
		return fallback
	}
	return value
}

func LoadEnvVariables() {
	err := godotenv.Load()

	if err != nil {
		log.Fatal("Error loading .env file")
	}

	v, err := strconv.Atoi(os.Getenv("SESSION_TIME"))
	if err == nil {
		auth.SessionTime = time.Duration(v)
	}
	v, err = strconv.Atoi(os.Getenv("REFRESH_TOKEN_TIME"))
	if err == nil {
		auth.RefreshTokenTime = time.Duration(v)
	}
}
