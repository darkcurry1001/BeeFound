import requests
import json
import random
import os

# List of example tokens
tokens = [
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDYyNzIxMDksInJvbGUiOiJiZWVrZWVwZXIiLCJ0eXBlIjoic2Vzc2lvbiIsInVzZXJfaWQiOjF9.5aH-ZN5mEQBjIh1UxCAIcSUIstik1ZcMsVKnQmox25Y',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDYyNzIxMjEsInJvbGUiOiJiZWVrZWVwZXIiLCJ0eXBlIjoic2Vzc2lvbiIsInVzZXJfaWQiOjJ9.cCnzsvEV73qaIkIokUVZIJ9nOKc0oJTVBxfpdk7YRD0',
    # Add more tokens as needed
]

# Function to generate random coordinates near Austria
def generate_random_coordinates():
    latitude = round(random.uniform(46.5, 49.5), 6)
    longitude = round(random.uniform(9, 17), 6)
    return latitude, longitude

# Function to make the API request
def make_api_request(token, latitude, longitude):
    url = 'http://localhost:3000/api/hive/found'
    headers = {'Token': token}
    data = {
        'json': json.dumps({
            'Latitude': str(latitude),
            'Longitude': str(longitude),
            'Type': 'found'
        }),
    }
    file_path = os.path.abspath(r'C:\\Users\simon\\OneDrive - Johannes Kepler Universität Linz\\Pictures\BIRD.png')
    files = {'img': open(file_path, 'rb')}

    response = requests.post(url, headers=headers, data=data, files=files)

    # Print the response for debugging (you can remove this in production)
    print(response.text)

# Generate 50 random hive locations
for _ in range(10):
    # Select a random token from the list
    selected_token = random.choice(tokens)

    # Generate random coordinates
    latitude, longitude = generate_random_coordinates()

    # Make the API request
    make_api_request(selected_token, latitude, longitude)